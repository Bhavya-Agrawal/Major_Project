target ip:192.168.124.1

for installing  iscsi-initiator-utils :

yum install iscsi-initiator-utils.i686

Discover targets at a given IP address:

iscsiadm --mode discoverydb --type sendtargets --portal 192.168.124.1 --discover

Login, must use a node record id found by the discovery:

iscsiadm --mode node --targetname  hello --portal 192.168.124.1:3260 --login

Logout:

iscsiadm --mode node --targetname  hello --portal 192.168.124.1:3260 --logout

for more help :
man iscsiadm

for check storage:
fdisk -l
