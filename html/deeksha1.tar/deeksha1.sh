mkdir /mnt/deeksha1
mount 192.168.43.142:/mnt/deeksha1 /mnt/deeksha1
