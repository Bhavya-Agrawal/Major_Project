password:q
ssh -X 192.168.122.1 firefox
