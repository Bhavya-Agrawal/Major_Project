mkdir /mnt/deeksha
mount 192.168.122.1:/mnt/deeksha /mnt/deeksha
